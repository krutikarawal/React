import './App.css';
import { BrowserRouter } from 'react-router-dom';
import { Routes, Route } from 'react-router-dom'
import Login from './components/Authentication/Login';
import Dashboard from './components/Dashboard';
import CountryCreate from './components/DashboardContent/CountryCreate';
import CountryDetails from './components/DashboardContent/CountryDetails';
import CountryEdit from './components/DashboardContent/CountryEdit';
import Footer from './components/Footer/Footer';
function App() {
  return (
    <>
    <div className="App page-wrapper">
   
      <BrowserRouter>
        <Routes>
          <Route path='/' element={<Login />} />
          <Route path='/dashboard' element={<Dashboard />} />
          {/* Nested Routing*/}
          <Route path='/country/create' element={<CountryCreate />}></Route>
          <Route path='/country/detail/:countryId' element={<CountryDetails />}></Route>
          <Route path='/country/edit/:countryId' element={<CountryEdit />}></Route>
        </Routes>
      </BrowserRouter>
    </div>
    <Footer></Footer>
  </>
  );
}

export default App;
