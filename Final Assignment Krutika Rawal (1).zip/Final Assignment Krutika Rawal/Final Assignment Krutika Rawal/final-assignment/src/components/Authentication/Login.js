import React from 'react';
import { Formik, Form, Field, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import { useNavigate } from 'react-router-dom';
import './Login.css';
import axios from 'axios'; // Import Axios

const loginSchema = Yup.object().shape({
  username: Yup.string().required('Username is required'),
  password: Yup.string().required('Password is required'),
});

const Login = () => {
  const navigate = useNavigate();

  const handleLogin = (values, { setSubmitting }) => {
    axios
      .get('http://localhost:3000/users')
      .then((response) => {
        const user = response.data.find(
          (u) => u.username === values.username && u.password === values.password
        );

        if (user) {
          navigate('/dashboard'); // Redirect to dashboard on successful login
        } else {
          alert('Invalid credentials');
        }
        setSubmitting(false); // Reset the form submission state
      })
      .catch((error) => {
        console.error('Error:', error);
        setSubmitting(false); // Reset the form submission state
      });
  };

  return (
    
    <div className="container mt-5">
      <div className="row justify-content-center">
        <div className="col-md-4  text-center">
          <img src="logo.png" alt="Globe" className="globe-img" />
          <h1>Country Management System</h1>
        </div>
      </div>
      <div className="row justify-content-center">
        <div className="col-md-4">
          <h2 className="login-title">Login</h2>
          <Formik
            initialValues={{
              username: '',
              password: '',
            }}
            validationSchema={loginSchema}
            onSubmit={handleLogin}
          >
            <Form>
              <div className="form-group">
                <label className="login" htmlFor="username">
                  Username
                </label>
                <Field type="text" name="username" className="form-control" />
                <ErrorMessage
                  name="username"
                  component="div"
                  className="error-message"
                />
              </div>
              <div className="form-group">
                <label className="login" htmlFor="password">
                  Password
                </label>
                <Field type="password" name="password" className="form-control" />
                <ErrorMessage
                  name="password"
                  component="div"
                  className="error-message"
                />
              </div>
              <button type="submit" className="btn btn-primary" id="btnLogin">
                Login
              </button>
            </Form>
          </Formik>
        </div>
      </div>
    </div>
  );
};

export default Login;
