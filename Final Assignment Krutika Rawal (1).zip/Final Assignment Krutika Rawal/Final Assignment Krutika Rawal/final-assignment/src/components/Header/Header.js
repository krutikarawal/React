import React from 'react';
import './Header.css';
import Logout from '../Authentication/Logout';

// Header Section
function Header() {
  return (
    <div>
      <div className="header">
        <div className="logo-container">
          <img src="logo.png" alt="CountryLogo" className="logo" />
        </div>
        <div className="header-right">
          <Logout />
        </div>
      </div>
    </div>
  );
}

export default Header;
