import React from 'react';
import { Pagination } from 'react-bootstrap';

// CountryPagination component takes 'currentPage', 'totalPages', and 'onPageChange' as props
const CountryPagination = ({ currentPage, totalPages, onPageChange }) => {
  
  // Function to render pagination items
  const renderPaginationItems = () => {

    // Create an array of length 'totalPages' and map over it to generate Pagination.Item components
    return Array.from({ length: totalPages }).map((_, index) => (
      <Pagination.Item
        key={index}

        // Mark the current page as active
        active={index + 1 === currentPage}

        // Call 'onPageChange' with the clicked page number
        onClick={() => onPageChange(index + 1)}
      >
        {index + 1}
      </Pagination.Item>
    ));
  };

  // Render the Pagination component with the generated pagination items
  return <Pagination>{renderPaginationItems()}</Pagination>;
};

export default CountryPagination;
