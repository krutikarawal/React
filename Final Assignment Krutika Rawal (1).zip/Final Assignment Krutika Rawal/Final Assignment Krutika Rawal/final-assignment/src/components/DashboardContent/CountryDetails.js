import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import axios from "axios";
import Header from "../Header/Header";

const CountryDetails = () => {
  // Extract 'countryId' from the URL parameters
  const { countryId } = useParams();

  // State to store country data retrieved from the server
  const [countryData, countryDataChange] = useState({});

  useEffect(() => {
    // Fetch country data from the server when the component mounts or 'countryId' changes
    axios
      .get(`http://localhost:3000/country/${countryId}`)
      .then((response) => {
        // Update the 'countryData' state with the fetched data
        countryDataChange(response.data);
      })
      .catch((error) => {
        console.log(error.message);
      });
  }, [countryId]); // The effect depends on 'countryId', so it runs when 'countryId' changes

  return (
    <div>
       <div><Header></Header></div>
      <div className="container">
        <div className="card row" style={{ textAlign: "left" }}>
          <div className="card-title">
            <h2>Country Details</h2>
          </div>
          <div className="card-body"></div>

          {/* Display country data if it exists */}
          {countryData && (
            <div>
              <h2>
                The Country name is : <b>{countryData.name}</b> ({countryData.id})
              </h2>
              <h5>Population is : {countryData.population}</h5>

              {/* Back to Listing button */}
              <Link className="btn btn-danger" to="/dashboard" id="btn">
                Back to Listing
              </Link>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default CountryDetails;
