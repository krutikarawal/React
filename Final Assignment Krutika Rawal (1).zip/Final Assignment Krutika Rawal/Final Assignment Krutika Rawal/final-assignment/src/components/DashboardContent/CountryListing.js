import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Table, Form, Button, Row, Col, Modal } from 'react-bootstrap';
import { Link, useNavigate } from 'react-router-dom';
import { useFormik } from 'formik';
import * as Yup from 'yup';
import CountryPagination from './CountryPagination';
import './CountryListing.css';

const CountryListing = () => {
  const [countries, setCountries] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [countriesPerPage] = useState(10);
  const navigate = useNavigate();
  const [showDeleteModal, setShowDeleteModal] = useState(false); // State for the delete confirmation modal
  const [recordToDelete, setRecordToDelete] = useState(null); // State to store the record being deleted

  const LoadDetail = (id) => {
    navigate(`/country/detail/${id}`);
  };
  const LoadEdit = (id) => {
    navigate(`/country/edit/${id}`);
  };
  const Removefunction = (id) => {
    // Show the delete confirmation modal
    setRecordToDelete(id);
    setShowDeleteModal(true);
  };

  // Function to delete a country by ID
  const deleteCountry = (id) => {
    axios
      .delete(`http://localhost:3000/country/${id}`)
      .then(() => {
        // Close the delete confirmation modal
        setShowDeleteModal(false);
  
        // Remove the deleted record from the state
        setCountries(countries.filter((country) => country.id !== id));
      })
      .catch((error) => {
        console.error('Error deleting record:', error);
      });
  };
  
  useEffect(() => {
    // Fetch data from JSON Server
    axios
      .get('http://localhost:3000/country')
      .then((response) => {
        setCountries(response.data);
      })
      .catch((error) => {
        console.error('Error fetching data:', error);
      });
  }, []);

  // Filter countries based on search query
  const filteredCountries = countries.filter((country) =>
    country.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Pagination
  const indexOfLastCountry = currentPage * countriesPerPage;
  const indexOfFirstCountry = indexOfLastCountry - countriesPerPage;
  const currentCountries = filteredCountries.slice(indexOfFirstCountry, indexOfLastCountry);

  const paginate = (pageNumber) => {
    setCurrentPage(pageNumber);
  };

  const renderTableRows = currentCountries.map((country) => (
    <tr key={country.id}>
      <td>{country.id}</td>
      <td>{country.name}</td>
      <td>{country.population}</td>
      <td>
        <button
          type="button"
          onClick={() => LoadEdit(country.id)}
          className="btn btn-success"
        >
          Edit
        </button>
        <button
          type="button"
          onClick={() => Removefunction(country.id)}
          className="btn btn-danger"
        >
          Remove
        </button>
        <button
          type="button"
          onClick={() => LoadDetail(country.id)}
          className="btn btn-primary"
        >
          Details
        </button>
      </td>
    </tr>
  ));

  // Formik and Yup
  const initialValues = {
    searchQuery: '',
  };

  const validationSchema = Yup.object({
    searchQuery: Yup.string().trim(),
  });

  const formik = useFormik({
    initialValues,
    validationSchema,
    onSubmit: (values) => {
      if (values.searchQuery.trim() === '') {
        // If the search input is empty, reset searchQuery
        setSearchQuery('');
      } else {
        setSearchQuery(values.searchQuery);
      }
      setCurrentPage(1);
    },
  });

  return (
    <div>
      <h1>Country List</h1>
      <div className="search-container">
        <Form onSubmit={formik.handleSubmit}>
          <Row>
            <Col md={8}> {/* Use Bootstrap's grid system */}
              <Form.Group controlId="searchInput">
                <Form.Control
                  type="text"
                  placeholder="Search Country"
                  name="searchQuery"
                  value={formik.values.searchQuery}
                  onChange={formik.handleChange}
                  isInvalid={formik.touched.searchQuery && formik.errors.searchQuery}
                />
                <Form.Control.Feedback type="invalid">
                  {formik.errors.searchQuery}
                </Form.Control.Feedback>
              </Form.Group>
            </Col>
            <Col md={4}> {/* Use Bootstrap's grid system */}
              <Button type="submit" variant="primary" className="search-button">
                Search
              </Button>
            </Col>
          </Row>
        </Form>
      </div>

      <div className="card-body">
        <div class="text-right">
        <Row>
        <Col md={6}></Col>
          <Col md={6}>
          <Link to="/country/create" className="btn btn-success" id="add">
            Add New (+)
          </Link>
          </Col>
        </Row>
        </div>
        <Table className="table table-bordered">
          <thead className="bg-dark text-white">
            <tr>
              <th>ID</th>
              <th>Name</th>
              <th>Population</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>{renderTableRows}</tbody>
        </Table>
      </div>

      {/* Include the CountryPagination component */}
      <div className="pagination-container">
        <CountryPagination
          currentPage={currentPage}
          totalPages={Math.ceil(filteredCountries.length / countriesPerPage)}
          onPageChange={paginate}
        />
      </div>
      {/* Modal for Delete Confirmation */}
      <Modal show={showDeleteModal} onHide={() => setShowDeleteModal(false)}>
        <Modal.Header closeButton>
          <Modal.Title>Confirm Deletion</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          Are you sure you want to delete this record?
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowDeleteModal(false)}>
            Cancel
          </Button>
          <Button
            variant="danger"
            onClick={() => {
              // Handle record deletion here
              // Call the deleteCountry function with the recordToDelete ID
              deleteCountry(recordToDelete);
            }}
          >
            Delete
          </Button>
        </Modal.Footer>
      </Modal>
    </div>
  );
};

export default CountryListing;
