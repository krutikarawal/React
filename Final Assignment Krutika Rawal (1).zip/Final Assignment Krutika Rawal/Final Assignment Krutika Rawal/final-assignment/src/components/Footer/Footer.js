import React from 'react'
import './Footer.css'

const Footer = () => {
  return (
    <div className='footer-section'>
          <p>Copyright &copy; {new Date().getFullYear()} React</p>
    </div>
  )
}

export default Footer