import React, { Component } from 'react'
import './Foot.css'

class Foot extends Component {
  render() {
  return (
    <div>
      {/* Footer Section */}
      <footer className="main-footer">
        <div className="container">
          <p>Aress Software & Education Technologies (P) Ltd. &copy; 2023 All rights reserved.</p>
        </div>
      </footer>
    </div>
  )
}
}

export default Foot

