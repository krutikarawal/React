import React from 'react'
import './Navbar.css'
import { Link, useMatch, useResolvedPath } from 'react-router-dom'

function Navbar() {

  return (
    <nav className='nav'>
      <Link to='/' className='site-title'>
        React Assignment 5
      </Link>
      <ul>
        <CustomLink to='/home'>HOME</CustomLink>
        <CustomLink to='/products'>PRODUCTS</CustomLink>
        <CustomLink to='/contact'>CONTACT US</CustomLink>
        <CustomLink to='/register'>SIGN UP</CustomLink>
        <CustomLink to='/login'>SIGN IN</CustomLink>
      </ul>
    </nav>
  )
}

// To show on Which link or page we are to highlight that link 
function CustomLink({ to, children, ...props }) {

  const resolvedPath = useResolvedPath(to)
  const isActive = useMatch({ path: resolvedPath.pathname, end: true })
  return (
    <li className={isActive ? "active" : ''}>
      <Link to={to} {...props}>
        {children}
      </Link>
    </li>
  )
}

export default Navbar