import React from 'react'
import './Search.css'

// function for showing the search section
function Search() {
  return (
    <div>
      <div class='wrap'>
        <div class='search'>
          <input
            type="text"
            class="searchTerm"
            placeholder='What are you looking for ?'
          />
        </div>
      </div>
    </div>
  )
}

export default  Search