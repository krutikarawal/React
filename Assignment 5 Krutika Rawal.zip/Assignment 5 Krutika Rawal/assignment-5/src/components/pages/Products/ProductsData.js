import img1 from './assests/images/tv.jpg'
import img2 from'./assests/images/mobile.jpg'

// Creating the dummy data for showing purpose
export const ProductsData = [
    {
      id: 1,
      name: "Product 1",
      description: "Description 1",
      price: 100,
      image: {img1},
    },
    {
      id: 2,
      name: "Product 2",
      description: "Description 2",
      price: 200,
      image: {img2},
    },
  ];