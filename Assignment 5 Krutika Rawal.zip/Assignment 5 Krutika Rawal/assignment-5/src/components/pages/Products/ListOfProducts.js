import React from 'react'
import { ProductsData } from './ProductsData'
import { useNavigate } from 'react-router-dom'

function ListOfProducts() {
  const navigate = useNavigate();
  return (
    <div className='listOfProducts'>
      <div className='productList'>
        {/* Function is used to iterate over the all products to take list of products from  ProductsData.js */}
        { ProductsData.map((product) => {
          return (
            <div
              className='productDisplay'
              // function represent the details of that specific product
              onClick={() => {
                navigate(`/products/${product.id}`);
              }}
            >
              <h1>{product.name}</h1> 
              <p>{product.description}</p> {" "}
              <h1>Rs:{product.price}</h1> 
            </div>
          );
        })}
      </div>
    </div>
  )
}

export default ListOfProducts