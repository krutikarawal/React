import React from 'react'

// function for showing Add Product
const AddProduct = () => {
  return (
    <div className="listOfProducts">
      <h1> Add Product</h1>
    </div>
  )
}

export default AddProduct