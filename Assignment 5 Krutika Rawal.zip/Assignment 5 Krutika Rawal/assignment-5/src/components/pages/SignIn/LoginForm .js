import React, { Component } from 'react';
import './LoginForm.css'

class LoginForm extends Component {
  constructor(props) {
    super(props);
    this.state = {
      email: '',
      password: '',
      errors: {
        email: '',
        password: '',
      },
    };
  }

  handleChange = (e) => {
    const { name, value } = e.target;
    this.setState({
      [name]: value,
    });
  };

  validateForm = () => {
    let { email, password, errors } = this.state;
    let isValid = true;

    // Validate email
    if (!email) {
      errors.email = 'Email is required';
      isValid = false;
    } else if (!/\S+@\S+\.\S+/.test(email)) {
      errors.email = 'Invalid email address';
      isValid = false;
    } else {
      errors.email = '';
    }

    // Validate password

    if (!password) {
      errors.password = 'Password is required';
      isValid = false;
    }
    else if (this.state.password.length < 8) {
      isValid = false;
      errors.password = 'Password must be atleast 8 characters long';
    }
    else if (!/(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*\W)/.test(this.state.password)) {
      isValid = false;
      errors.password = 'Password must contain at least one digit, one lowercase letter, one uppercase letter, and one special character';
    }
    else {
      errors.password = '';
    }

    this.setState({ errors });
    return isValid;
  };

  // Handling on submit activities
  handleSubmit = (e) => {
    e.preventDefault();
    if (this.validateForm()) {
      // Acessing the current state of data and showing it
      this.setState({
        visibility: 'block',
        display:
         <div>
          <p><b>Login successful</b></p><br></br>
        </div>
      })
    }
  };

  render() {
    const { email, password, errors } = this.state;

    return (
      <div className="login-form">
        <h2>Login</h2>
        <form onSubmit={this.handleSubmit}>
          <div className="form-group">
            <label htmlFor="email">Email</label>
            <input
              type="email"
              id="email"
              name="email"
              value={email}
              placeholder='Email'
              onChange={this.handleChange}
            />
            <div className="error">{errors.email}</div>
          </div>
          <div className="form-group">
            <label htmlFor="password">Password</label>
            <input
              type="password"
              id="password"
              placeholder='Password'
              name="password"
              value={password}
              onChange={this.handleChange}
            />
            <div className="error">{errors.password}</div>
          </div>
          <div className="form-group">
            <button type="submit">Sign In</button>
          </div>
        </form>
        <div>{this.state.display}</div>

      </div>
    );
  }
}

export default LoginForm;




