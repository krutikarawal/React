import React, { useState } from 'react';
import { Formik, Form, Field, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import './Contact.css'

// Validations for Each Fields Through Yup library
const ContactFormSchema = Yup.object().shape({
  name: Yup.string().required('First Name is required'),
  email: Yup.string()
    .email('Invalid email')
    .required('Email is required')
    .matches(/^[a-zA-Z0-9._%+-]+@gmail\.com$/, 'Email must be in the format user@gmail.com'),
  mobileNumber: Yup.string()
    .matches(/^\d{10}$/, 'Mobile number must be 10 digits')
    .required('Mobile Number is required'),
  subject: Yup.string().required('Subject is required'),
  message: Yup.string().required('Message is required'),
});

const Contact = () => {
  const initialValues = {
    name: '',
    email: '',
    mobileNumber: '',
    subject: '',
    message: '',
  };

  const [submittedData, setSubmittedData] = useState(null);

  const handleSubmit = (values) => {
    console.log('Form data submitted:', values);
    setSubmittedData(values);
  };

  return (
    <div className="container">

      <div className="row">
        <div className="col-lg-6 offset-lg-3">
          <div className="section-header wow fadeInUp" data-wow-duration="1000ms" data-wow-delay="10ms">
            <h2>CONTACT US</h2>
            <p>Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet consectetur,adipisci velit, sed quia
              non
              numquam</p>
            <p><a href="mailto:info@test.com"><i className="fas fa-envelope"></i>info@test.com</a></p>
            <p><a href="tel:+912536630710"><i className="fas fa-phone-alt"></i> +91 253 6630710</a></p>
          </div>
        </div>
      </div>

      <div className="row">
        <div className="col-md-8 offset-md-2">
          <div className="contact-form">
            <Formik
              initialValues={initialValues}
              validationSchema={ContactFormSchema}
              onSubmit={handleSubmit}
            >
              <Form>
                <div className="form-group">
                  <label htmlFor="Name">Name</label>
                  <Field type="text" name="name" />
                  <ErrorMessage name="name" component="div" className="error" />
                </div>

                <div className="form-group">
                  <label htmlFor="email">Email</label>
                  <Field type="email" name="email" />
                  <ErrorMessage name="email" component="div" className="error" />
                </div>

                <div className="form-group">
                  <label htmlFor="mobileNumber">Mobile Number</label>
                  <Field type="text" name="mobileNumber" />
                  <ErrorMessage
                    name="mobileNumber"
                    component="div"
                    className="error"
                  />
                </div>

                <div className="form-group">
                  <label htmlFor="subject">Subject</label>
                  <Field type="text" name="subject" />
                  <ErrorMessage name="subject" component="div" className="error" />
                </div>

                <div className="form-group">
                  <label htmlFor="message">Message</label>
                  <Field type="text" name="message" />
                  <ErrorMessage name="message" component="div" className="error" />
                </div>
                <button type="submit">SEND MESSAGE</button>
              </Form>
            </Formik>
            {/* Display submitted data in a new div Method 2*/}
            {submittedData && (
              <div className="submitted-data">
                <h2>Message Send !!!</h2>
                <h2>Submitted Data</h2>
                <p>Name: {submittedData.name}</p>
                <p>Email: {submittedData.email}</p>
                <p>Mobile Number: {submittedData.mobileNumber}</p>
                <p>Subject: {submittedData.subject}</p>
                <p>Message: {submittedData.message}</p>
              </div>
            )}
          </div>
        </div>
      </div>

    </div>
  );
};

export default Contact 