import React, { useState } from 'react';
import { Formik, Form, Field, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import './RegisterForm.css'


// Validations for Each Fields Through Yup library
const RegisterFormSchema = Yup.object().shape({
  firstName: Yup.string().required('First Name is required'),
  lastName: Yup.string().required('Last Name is required'),
  email: Yup.string()
    .email('Invalid email')
    .required('Email is required')
    .matches(/^[a-zA-Z0-9._%+-]+@gmail\.com$/, 'Email must be in the format user@gmail.com'),

  password: Yup.string()
    .min(8, 'Password must be at least 8 characters')
    .required('Password is required'),

  confirmPassword: Yup.string()
    .oneOf([Yup.ref('password'), null], 'Passwords must match')
    .required('Confirm Password is required'),

  mobileNumber: Yup.string()
    .matches(/^\d{10}$/, 'Mobile number must be 10 digits')
    .required('Mobile Number is required'),

  state: Yup.string().required('State is required'),

  gender: Yup.string().required('Gender is required'),

  city: Yup.string().required('City is required'),
});

const RegisterForm = () => {
  const initialValues = {
    firstName: '',
    lastName: '',
    email: '',
    password: '',
    confirmPassword: '',
    mobileNumber: '',
    state: '',
    gender: '',
    city: '',
  };

  const [submittedData, setSubmittedData] = useState(null);

  const handleSubmit = (values) => {
    console.log('Form data submitted:', values);
    setSubmittedData(values);
  };

  return (
    <div className="signup-form">
      <h2>Sign Up</h2>
      <Formik
        initialValues={initialValues}
        validationSchema={RegisterFormSchema}
        onSubmit={handleSubmit}
      >
        <Form>
          <div className="form-group">
            <label htmlFor="firstName">First Name</label>
            <Field type="text" name="firstName" />
            <ErrorMessage name="firstName" component="div" className="error" />
          </div>

          <div className="form-group">
            <label htmlFor="lastName">Last Name</label>
            <Field type="text" name="lastName" />
            <ErrorMessage name="lastName" component="div" className="error" />
          </div>

          <div className="form-group">
            <label htmlFor="email">Email</label>
            <Field type="email" name="email" />
            <ErrorMessage name="email" component="div" className="error" />
          </div>

          <div className="form-group">
            <label htmlFor="password">Password</label>
            <Field type="password" name="password" />
            <ErrorMessage name="password" component="div" className="error" />
          </div>

          <div className="form-group">
            <label htmlFor="confirmPassword">Confirm Password</label>
            <Field type="password" name="confirmPassword" />
            <ErrorMessage
              name="confirmPassword"
              component="div"
              className="error"
            />
          </div>

          <div className="form-group">
            <label htmlFor="mobileNumber">Mobile Number</label>
            <Field type="text" name="mobileNumber" />
            <ErrorMessage
              name="mobileNumber"
              component="div"
              className="error"
            />
          </div>

          <div className="form-group">
            <label htmlFor="state">State</label>
            <Field type="text" name="state" />
            <ErrorMessage name="state" component="div" className="error" />
          </div>

          <div className="form-group">
            <label>Gender</label>
            <div role="group" aria-labelledby="gender-label">
              <label>
                <Field type="radio" name="gender" value="male" />
                Male
              </label>
              <label>
                <Field type="radio" name="gender" value="female" />
                Female
              </label>
              <label>
                <Field type="radio" name="gender" value="other" />
                Other
              </label>
            </div>
            <ErrorMessage name="gender" component="div" className="error" />
          </div>

          <div className="form-group">
            <label htmlFor="city">City</label>
            <Field as="select" name="city">
              <option value="">Select City</option>
              <option value="Nashik">Nashik</option>
              <option value="Pune">Pune</option>
              <option value="Mumbai">Mumbai</option>
            </Field>
            <ErrorMessage name="city" component="div" className="error" />
          </div>

          <button type="submit">Submit</button>
        </Form>
      </Formik>

      {/* Display submitted data in a new div Method 2*/}
      {submittedData && (
        <div className="submitted-data">
          <h2>Congrats You Are Registered Successfully</h2>
        </div>
      )}   

    </div>
  );
};


export default RegisterForm