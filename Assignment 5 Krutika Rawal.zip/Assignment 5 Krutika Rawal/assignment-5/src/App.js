import './App.css';
import Navbar from './components/Navbar/Navbar';
import Home from './components/pages/Home/Home';
import Contact from './components/pages/Contact/Contact';
import { Routes, Route } from 'react-router-dom';
import LoginForm from './components/pages/SignIn/LoginForm ';
import RegisterForm from './components/pages/SignUp/RegisterForm';
import Products from './components/pages/Products/Products';
import Search from './components/pages/Products/Search';
import ListOfProducts from './components/pages/Products/ListOfProducts';
import AddProduct from './components/pages/Products/AddProduct';
import ProductDisplay from './components/pages/Products/ProductDisplay';
import Foot from './components/Footer/Foot';

function App() {
  return (
    <div className="App">
      <Navbar />
      <div className='container'>
        <Routes>
          <Route path='/home' element={<Home />} />
          <Route path="products" element={<Products />}>
            <Route path="search" element={<Search />} />
            <Route path="list" element={<ListOfProducts />} />
            <Route path="add" element={<AddProduct />} />
            <Route path=":id" element={< ProductDisplay />} />
          </Route>
          <Route path='/contact' element={<Contact />} />
          <Route path='/login' element={<LoginForm />} />
          <Route path='/register' element={<RegisterForm />} />
        </Routes>
      </div>
      <Foot/>

    </div>
  );
}

export default App;
