import { useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { Formik, Form, Field } from 'formik';
import { object, string } from 'yup';

const initialValues = {
  name: '',
  email: '',
  phone: ''
}

const EmpEdit = () => {
  const { empid } = useParams();

  //const variable
  const phoneRegExp = /^[0-9]{10}$/;

  const validationSchema = object({
    name: string().required().min(3).max(30),
    email: string().email('Invalid email').required('Email is required'),
    phone: string().matches(phoneRegExp, 'phone number is not valid').required('Phone number is required')
  });

  useEffect(() => {
    fetch("http://localhost:3000/employee/" + empid).then((res) => {
      return res.json();
    }).then((resp) => {
      idchange(resp.id);
      namechange(resp.name);
      emailchange(resp.email);
      phonechange(resp.phone);
      activechange(resp.isactive);
      initialValues.name = resp.name;
      initialValues.email = resp.email;
      initialValues.phone = resp.phone;
    }).catch((err) => {
      console.log(err.message);
    })
  }, []);

  const [id, idchange] = useState("");
  const [name, namechange] = useState("");
  const [email, emailchange] = useState("");
  const [phone, phonechange] = useState("");
  const [active, activechange] = useState(true);
  
  const navigate = useNavigate();

  const handleSubmit = (values) => {
   
    fetch("http://localhost:3000/employee/" + empid, {
      method: "PUT",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(values)
    }).then((res) => {
      alert('Saved successfully.')
      navigate('/');
    }).catch((err) => {
      console.log(err.message)
    })

  }
  return (
    <div>

      <div className="row">
        <div className="offset-lg-3 col-lg-6">
          <Formik initialValues={initialValues} validationSchema={validationSchema} onSubmit={handleSubmit}>
            {({ values, errors }) => (
              <Form className="container" >

                <div className="card" style={{ "textAlign": "left" }}>
                  <div className="card-title">
                    <h2>Employee Edit</h2>
                  </div>
                  <div className="card-body">

                    <div className="row">

                      <div className="col-lg-12">
                        <div className="form-group">
                          <label>ID</label>
                          <input value={id} disabled="disabled" className="form-control"></input>
                        </div>
                      </div>

                      <div className="col-lg-12">
                        <div className="form-group">
                          <label htmlFor="name">Name</label>
                          <Field type="text" id="name" name='name' className="form-control" />
                          <p className="err">{errors.name}</p>
                        </div>
                      </div>

                      <div className="col-lg-12">
                        <div className="form-group">
                          <label htmlFor="email">Email</label>
                          <Field type="email" id="email" name='email' className="form-control" />
                          <p className="err">{errors.email}</p>
                        </div>
                      </div>

                      <div className="col-lg-12">
                        <div className="form-group">
                          <label>Phone</label>
                          <Field type="string" id="phone" name='phone' className="form-control" />
                          <p className="err">{errors.phone}</p>
                        </div>
                      </div>

                      <div className="col-lg-12">
                        <div className="form-check">
                          <input checked={active} onChange={e => activechange(e.target.checked)} type="checkbox" className="form-check-input"></input>
                          <label className="form-check-label">Is Active</label>

                        </div>
                      </div>
                      <div className="col-lg-12">
                        <div className="form-group">
                          <button className="btn btn-success" type="submit">Save</button>
                          <Link to="/" className="btn btn-danger">Back</Link>
                        </div>
                      </div>

                    </div>

                  </div>

                </div>

              </Form>
            )}
          </Formik>

        </div>
      </div>
    </div>
  );
}

export default EmpEdit;