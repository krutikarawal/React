import React from 'react'
import { useNavigate } from 'react-router-dom'
import { object } from 'yup'
import * as Yup from 'yup'
import { Formik, Form, Field, ErrorMessage } from 'formik'

// initial values
const initialValues = {
  name: '',
  phone: '',
  email: '',
  active: '',
}

export default function EmpCreate() {
  const navigate = useNavigate();

  const validationSchema = object({
    name: Yup.string()
      .min(3, 'Employee name must be at least 3 characters')
      .max(20, 'Employee name must not exceed 20 characters')
      .required('Employee Name is required'),
    phone: Yup.string()
      .required('Phone number is required')
      .min(10, 'Phone number must contain at least 10 digits')
      .max(12, 'Phone number must not exceed 12 characters'),
    email: Yup.string().email('Not a proper email').required('Email is Required'),
  });

  /**
   * 
   * @param {*} values 
   */
  const AddEmployeeFormSubmit = (values) => {

    fetch('http://localhost:3000/employee', {
      method: 'POST',
      headers: { "content-type": "application/json" },
      body: JSON.stringify(values)
    }).then(() => {
      // Display a Bootstrap alert for success
      const alertElement = document.createElement('div');
      alertElement.className = 'alert alert-success mt-4';
      alertElement.innerHTML = 'Employee added successfully';

      // Append the alert to the container
      const container = document.querySelector('.container');
      container.appendChild(alertElement);

      // Automatically remove the alert after 2 seconds (2000 milliseconds)
      setTimeout(() => {
        container.removeChild(alertElement);
      }, 3000);

      navigate('/');
    })
  }

  const backButtontoHome = () => {
    navigate('/')
  }

  return (
    <>
      <div className=''>
        <Formik initialValues={initialValues} validationSchema={validationSchema} onSubmit={AddEmployeeFormSubmit} >
          {({ values, }) => (
            <Form>
              <section className="vh-100">
                <div className="container py-5">
                  <div className="row d-flex justify-content-center align-items-center h-50">
                    <div className="col-12 col-md-8 col-lg-6 col-xl-5">
                      <div className="card shadow-2-strong" >
                        <div className="card-body p-4 text-center">
                          <h3 className="mb-4 heading">Add Employee</h3>
                          <div className="form-outline mb-4">
                            <Field type="text" disabled id="" className="form-control form-control-lg" name='id' placeholder='id' />
                          </div>
                          <div className="form-outline mb-4">
                            <p className='labels mx-2'>Employee Name : </p>
                            <Field type="text" id="" name="name" className="form-control form-control-lg" placeholder='Employee Name' />
                            <ErrorMessage name="name" component="div" className="error"></ErrorMessage>
                          </div>
                          <div className="form-outline mb-4">
                            <p className='labels mx-2'>Phone : </p>
                            <Field type="text" id="" className="form-control form-control-lg" name='phone' placeholder='Phone' />
                            <ErrorMessage name="phone" component="div" className="error"></ErrorMessage>
                          </div>
                          <div className="form-outline mb-4">
                            <p className='labels mx-2'>Email : </p>
                            <Field type="email" id="" className="form-control form-control-lg" name='email' placeholder='Email' />
                            <ErrorMessage name="email" component="div" className="error"></ErrorMessage>
                          </div>
                          <button className="btn btn-primary btn-lg btn-block mx-3" type="submit" >Save</button>
                          <button className="btn btn-primary btn-lg btn-block" type="button" onClick={backButtontoHome} >Back</button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </section>
            </Form>
          )}
        </Formik>
      </div>
    </>
  )
}