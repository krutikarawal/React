import React from "react";
import './Footer.css'

const Footer = () => {
    return (
      <footer className="footer-custom text-center mt-auto">
        {/* Footer content */}
        <div className="container">
          &copy; {new Date().getFullYear()} React. All Rights Reserved.
        </div>
      </footer>
    );
  };
  
  export default Footer;