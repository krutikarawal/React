import React from 'react';
import './Navbar.css'; // Import custom styles

const Navbar = () => {
  return (
    <nav className="navbar navbar-expand-lg navbar-custom">
      {/* Navbar content */}
      <div className="container">
        <a className="navbar-brand" href="#">
          React Assignment 6
        </a>
      </div>
    </nav>
  );
};

export default Navbar;
