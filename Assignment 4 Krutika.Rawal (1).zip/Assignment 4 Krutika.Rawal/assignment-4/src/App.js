
import './App.css';
import Navbar from './components/Navbar/Navbar';
import Banner from './components/Banner/Banner';
import Buttons from './components/Forms/Buttons';

function App() {
  return (
    <div className="App">
      <Navbar/>
      <Banner/>
      <Buttons/>
    </div>
  );
}

export default App;
