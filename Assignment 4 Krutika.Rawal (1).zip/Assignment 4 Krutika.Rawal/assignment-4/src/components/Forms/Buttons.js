import React, { Component } from 'react'
import Button from './Button'
import LoginForm from './LoginForm '
import RegisterForm from './RegisterForm'
import './Buttons.css'

export default class Buttons extends Component {

  constructor(props) {
    super(props)

    this.state = {
      form: ''
    }
  }

  one = () => {
    this.setState({
      form: <LoginForm />
    })
  }

  two = () => {
    this.setState({
      form: <RegisterForm />
    })
  }

  render() {
    return (

      <div>
        <div className='card'>
          <div className="row">
            <div className="col">
              <Button msg={this.one} color="primary" btnName="Sign In"></Button>
            </div>
            <div className="col">
              <Button msg={this.two} color="success" btnName="Sign Up"></Button>
            </div>
          </div>
          {this.state.form}
        </div>
      </div>

    )
  }
}