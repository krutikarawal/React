// DisplayComponent.js 
import React, { Component } from 'react';
import './Display.css'

class Display extends Component {
  render() {
    const { userInput } = this.props;

    return (
      <div className="display-container">
        <h2>Display Component</h2>
        <div class="outer">
          <div>{userInput}</div>
        </div>

      </div>
    );
  }
}

export default Display;
