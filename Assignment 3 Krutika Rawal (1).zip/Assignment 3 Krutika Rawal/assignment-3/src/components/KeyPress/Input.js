// InputComponent.js
import React, { Component } from 'react';
import './Input.css'
import Display from './Display';

class Input extends Component {
  constructor(props) {
    super(props);
    this.state = {
      userInput: '',
    };
  }

  handleInputChange = (e) => {
    const userInput = e.target.value;
    this.setState({ userInput });
  };

  render() {
    return (
      <div className="input-container">
        <h2>Input Component</h2>
        <input
          type="text"
          placeholder="Type something..."
          onChange={this.handleInputChange}
          value={this.state.userInput}
        />
        <Display userInput={this.state.userInput} />
      </div>
    );
  }
}

export default Input;

