import React, { Component } from 'react'
import Button from './Button'
import './ReusableButton.css'

class ReusableButton extends Component {

  constructor(props) {
    super(props)

    this.state = {
      message: "HELLO"
    }
  }

  handleMessage1 = (message) => {
    this.setState({
      message: 'WELCOME TRAINEES'
    })
  }

  handleMessage2 = (message) => {
    this.setState({
      message: 'THANK YOU FOR VISITING'
    })
  }

  handleMessage3 = (message) => {
    this.setState({
      message: 'BYE'
    })
  }

  render() {
    return (
      <div className='card'>
        <h2 className='message text-center'>{this.state.message}</h2>

        <div className="d-flex justify-content-around">
          <div className='d-flex justify-content-around'>
            <Button color="primary" handleMessage={this.handleMessage1} btnName="Welcome" ></Button>
          </div>
          <div className='d-flex justify-content-around' >
            <Button color="dark" handleMessage={this.handleMessage2} btnName="Thank you" ></Button>
          </div>
          <div className='d-flex justify-content-around' >
            <Button color="success" handleMessage={this.handleMessage3} btnName="Bye" ></Button>
          </div>
        </div>

      </div>
    )
  }
}

export default ReusableButton

