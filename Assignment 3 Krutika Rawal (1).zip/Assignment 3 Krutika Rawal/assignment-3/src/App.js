import React from 'react';
import './App.css';
import Navbar from './components/Navbar/Navbar';
import Banner from './components/Banner/Banner';
import Foot from './components/Footer/Foot';
import ReusableButton from './components/Button/ReusableButton';
import Input from './components/KeyPress/Input';


function App() {
  return (
    <div className="App">
      <Navbar></Navbar>
      <Banner></Banner>
      <ReusableButton></ReusableButton>
      <Input/>
      <Foot></Foot>
    </div>
  );
}

export default App;
