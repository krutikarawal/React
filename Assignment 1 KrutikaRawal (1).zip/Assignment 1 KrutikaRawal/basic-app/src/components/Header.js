import React from 'react';

function Header() {
    return (

        <header className="main-header fixed-top">
            <nav className="navbar navbar-expand-md">
                <div className="container">
                    <a className="navbar-brand" href="#">React Assignment 2</a>
                </div>
            </nav>
        </header>
    )
}

export default Header;