import React from "react";

function RestSpread() {
    // Spread Example 
    let values = [15, 48, 32, 56, 72, 24];
    const minimun = Math.min(...values)

    // Rest Example
    function Fruits(...AllFruits) {
        var fruits = []
        for (var i = 0; i < AllFruits.length; i++) {
            fruits[i] = AllFruits[i];
        }
        return fruits
    }

    return (
        <div>
            <h3> Mininmun number in array using spread : {minimun} </h3>
            <h3>List of Fruits using Rest : {Fruits("Mango", ',',"Orange",',', "Apple", ',',"Strawberry")}</h3>
        </div>
    );
}

export default RestSpread;