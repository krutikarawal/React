import React, { Component } from "react";

class MapReduceFilter extends Component {
    constructor() {
        super();
        this.state = {
            numbers: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
        };
    }

    // Method to return the squared values of the numbers array using map
    getSquaredValues = () => {
        return this.state.numbers.map((number) => number * number * number)  ;
    };

    // Method to return the sum of all values in the numbers array using reduce
    getSum = () => {
        return this.state.numbers.reduce((accumulator, currentValue) => accumulator + currentValue, 0);
    };

    // Method to return even numbers from the numbers array using filter
    getEvenNumbers = () => {
        return this.state.numbers.filter((number) => number % 2 === 0);
    };

    render() {
        return (
            <div>
                <h1>Use of Map Reduce Filter</h1>
                <p> Original Numbers: {this.state.numbers.join(',')}</p>
                <p>Cube Values Using Map: {this.getSquaredValues().join(',')}</p>
                <p>Sum of Values Using Reduce: {this.getSum()}</p>
                <p>Even Numbers Using Filter: {this.getEvenNumbers().join(',')}</p>
            </div>
        );
    }
}

export default MapReduceFilter;