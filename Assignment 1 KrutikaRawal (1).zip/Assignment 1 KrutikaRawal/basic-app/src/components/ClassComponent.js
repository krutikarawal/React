//class Component
import React, { Component } from "react";

class ClassComponent extends Component {
  constructor() {
    super();
    this.state = {
      counter: 0,
    };
  }

  HandleIncreament = () => {
    this.setState((prevState) => ({
      counter: prevState.counter + 1,
    }));
  };

  HandleDecreament = () => {
    this.setState((prevState) => ({
      counter: prevState.counter - 1,
    }));
  };

  render() {
    return (
      <div className="section">
        <h2>Class Component</h2>
        <p> Counter: {this.state.counter}</p>
        <button onClick={this.HandleIncreament} className="button">Increament</button>
        <button onClick={this.HandleDecreament} className="button">Decreament</button>
      </div>
    );
  }
}

export default ClassComponent;