import React, { use, useState } from "react";

function FunctionalComponent() {
  const [num1, setNum1] = useState('');
  const [num2, setNum2] = useState('');
  const [result, setResult] = useState('');
  const [operation, setOperation] = useState('');

  const HandleNum1Change = (e) => {
    setNum1(e.target.value);
  };

  const HandleNum2Change = (e) => {
    setNum2(e.target.value);
  };

  const HandleOperationChange = (e) => {
    setOperation(e.target.value);
  };

  const calculate = () => {
    let num1Float = parseFloat(num1);
    let num2Float = parseFloat(num2);
    let calculatedResult = 0;

    switch (operation) {
      case '+':
        calculatedResult = num1Float + num2Float;
        break;
      case '-':
        calculatedResult = num1Float - num2Float;
        break;
      case '*':
        calculatedResult = num1Float * num2Float;
        break;
      case '/':
        if (num2Float !== 0) {
          calculatedResult = num1Float / num2Float;
        } else {
          calculatedResult = 'Division by zero is not allowed.';
        }
        break;
      default:
        calculatedResult = 'Invalid operation';
    }

    setResult(calculatedResult);
  };

  return (
    <div>
      <h2>Simple calculator</h2>
      <div>
        <input
          type="number"
          placeholder="Enter number 1"
          value={num1}
          onChange={HandleNum1Change}
          className="inputs"
        />
        <select onChange={HandleOperationChange} className="selection">
          <option value="+" className="selected">+</option>
          <option value="-" className="selected">-</option>
          <option value="*" className="selected">*</option>
          <option value="/" className="selected">/</option>
        </select>
        <input
          type="number"
          placeholder="Enter number 2"
          value={num2}
          onChange={HandleNum2Change}
          className="inputs"
        />
        <button onClick={calculate} className="btn">=</button>
      </div>
      <p>Result: {result}</p>
    </div>
  );

}

export default FunctionalComponent;