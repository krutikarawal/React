import logo from './logo.svg';
import './App.css';
import Header from './components/Header';
import ClassComponent from './components/ClassComponent';
import FunctionalComponent from './components/FunctionalComponent';
import MapReduceFilter from './components/MapReduceFilter';
import RestSpread from './components/RestSpread';


function App() {
  return (
    <div className="App">
      <Header></Header>
      <ClassComponent></ClassComponent>
      <FunctionalComponent></FunctionalComponent>
      <MapReduceFilter></MapReduceFilter>
      <RestSpread></RestSpread>
    </div>
  );
}

export default App;
