import logo from './logo.svg';
import './App.css';
import Navbar from './components/Navbar/Navbar';
import Banner from './components/Banner/Banner';
import StaticSection from './components/Static Section/StaticSection';
import Button from './components/StateChange/Button';
import Foot from './components/Footer/Foot';



function App() {
  return (
    <div className="App">

      {/* Display of All Components */}
      <Navbar></Navbar>
      <Banner></Banner>
      <StaticSection></StaticSection>
      <Button></Button>
      <Foot></Foot>
      
    </div>
  );
}

export default App;
