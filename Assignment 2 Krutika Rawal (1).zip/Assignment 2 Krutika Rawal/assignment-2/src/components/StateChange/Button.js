import React, { useState } from 'react'
import './Button.css'

function Button() {
  const [message, setMessage] = useState("Hello KRUTIKA !");

  const handleClick = () => {
    setMessage("Welcome  KRUTIKA !");
  };

  return (
    // Change Message Section
    <div className='button-section'>
      <h1>{message}</h1>
      <button onClick={handleClick}>Click Me</button>
    </div>
  )
}

export default Button


