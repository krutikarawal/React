import React from 'react'
import './StaticSection.css'

function StaticSection() {
  return (
    <div>
      {/* Contact Form Section For Static Display of Contents */}
      <div className="contact-us clearfix">
        <div className="container">
          <div className="row">
            <div className="col-lg-6 offset-lg-3">
              <div className="section-header wow fadeInUp" data-wow-duration="1000ms" data-wow-delay="10ms">
                <h2>CONTACT US</h2>
                <p>Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet consectetur,adipisci velit, sed quia
                  non
                  numquam</p>
                <p><a href="mailto:info@test.com"><i className="fas fa-envelope"></i>info@test.com</a></p>
                <p><a href="tel:+912536630710"><i className="fas fa-phone-alt"></i> +91 253 6630710</a></p>
              </div>
            </div>
          </div>
          <div className="row">
            <div className="col-md-8 offset-md-2">
              <form>
                <div className="form-group">
                  <label htmlFor="name">Your Name <span className="required-field">*</span></label>
                  <input type="text" name="name" className="form-control" id="name" placeholder="Your Name" />
                  <div className="error-message">Error message will be here</div>
                </div>
                <div className="form-group">
                  <label htmlFor="email">Your Email</label>
                  <input type="email" className="form-control" name="email" id="email" placeholder="Your Email" />
                </div>
                <div className="form-group">
                  <label htmlFor="subject">Subject</label>
                  <input type="text" className="form-control" name="subject" id="subject" placeholder="Subject" />
                </div>
                <div className="form-group">
                  <label>Message</label>
                  <textarea className="form-control" name="message" rows="5"></textarea>
                </div>
                <button type="submit" className="btn pull-left">SEND MESSAGE</button>
              </form>
            </div>
          </div>
        </div>
      </div>


    </div >
  )
}

export default StaticSection