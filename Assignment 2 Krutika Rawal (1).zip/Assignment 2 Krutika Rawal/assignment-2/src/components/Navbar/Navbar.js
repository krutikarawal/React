import React from 'react'
import './Navbar.css'

function Navbar() {
  return (
    <div>
      {/* Navbar Section */}
      <div className="page-wrapper">
        <header className="main-header clearfix">
          <div className="container">
            <div className="logo">
              <figure><a href="index.html">React Training</a></figure>
            </div>
            <nav className="navbar clearfix">
              <div className="topnav" id="Topnav">
                <ul>
                  <li><a href="index.html" className="active">HOME</a></li>
                  <li><a href="#">SERVICES</a></li>
                  <li><a href="#">PORTFOLIO</a></li>
                  <li><a href="#">CONTACT</a></li>
                </ul>
              </div>
            </nav>
          </div>
        </header>
      </div>
    </div>
  )
}

export default Navbar